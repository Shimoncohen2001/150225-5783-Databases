# DataBase_shimon-Yoel5783
Our project is: Basketball Leagues!


Here we will have all the SQL scripts and the entities to build database for the mini-project

Our team workes on:
- Injury
- Draft
- Position
